date +"ఇపుడు సమయం ,%_I గంటల %M నిమిషాలు" | espeak-ng -s 120 -p 75 -v te


